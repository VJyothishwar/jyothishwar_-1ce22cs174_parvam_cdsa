document.addEventListener("DOMContentLoaded", () => {
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");
  const confirmPasswordInput = document.getElementById("confirm_password");

  const loginBtn = document.getElementById("login");
  const signinBtn = document.getElementById("signin");
  const logoutBtn = document.getElementById("logout");
  const welcomeMsg = document.getElementById("welcomeMsg");

  // ------------------ SIGN UP ------------------
  if (signinBtn) {
    signinBtn.addEventListener("click", () => {
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();
      const confirmPassword = confirmPasswordInput.value.trim();

      if (!email || !password || !confirmPassword) {
        alert("⚠️ Please fill all fields");
        return;
      }
      if (password !== confirmPassword) {
        alert("❌ Passwords do not match");
        return;
      }

      let users = JSON.parse(localStorage.getItem("users")) || [];
      if (users.some(user => user.email === email)) {
        alert("⚠️ User already exists. Please login.");
        return;
      }

      users.push({ email, password });
      localStorage.setItem("users", JSON.stringify(users));

      alert("✅ Account created! Redirecting to login...");
      window.location.href = "login.html"; // redirect to login
    });
  }

  // ------------------ LOGIN ------------------
  if (loginBtn) {
    loginBtn.addEventListener("click", () => {
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();

      if (!email || !password) {
        alert("⚠️ Please fill all fields");
        return;
      }

      let users = JSON.parse(localStorage.getItem("users")) || [];
      const validUser = users.find(
        user => user.email === email && user.password === password
      );

      if (validUser) {
        localStorage.setItem("currentUser", JSON.stringify(validUser));
        alert("✅ Login successful! Redirecting...");
        window.location.href = "index.html"; // redirect to main page
      } else {
        alert("❌ Invalid email or password");
      }
    });
  }

  // ------------------ MAIN PAGE ------------------
  if (welcomeMsg) {
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (!currentUser) {
      // if no active user, redirect to login
      window.location.href = "login.html";
    } else {
      welcomeMsg.textContent = `Hello, ${currentUser.email}`;
    }
  }

  // ------------------ LOGOUT ------------------
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("currentUser");
      window.location.href = "login.html";
    });
  }
});

const inventoryData = [
  { vaccineType: "Covaxin", dosesAvailable: 1200, expiry: "2025-12-01" },
  { vaccineType: "Covishield", dosesAvailable: 1500, expiry: "2025-11-15" },
  { vaccineType: "Sputnik V", dosesAvailable: 800, expiry: "2025-10-30" }
];

function updateInventory() {
  inventoryData.forEach(vaccine => {
    const card = document.getElementById(`inv-${vaccine.vaccineType.toLowerCase().replace(" ", "")}`);
    if (card) {
      card.querySelector(".stat").textContent = vaccine.dosesAvailable;
      card.querySelector("p:nth-child(3)").textContent = `Expiry Date: ${vaccine.expiry}`;

      // Status Logic
      const today = new Date();
      const expiryDate = new Date(vaccine.expiry);
      const daysLeft = (expiryDate - today) / (1000 * 60 * 60 * 24);

      let statusEl = card.querySelector(".status");
      if (daysLeft < 0) {
        statusEl.textContent = "Expired";
        statusEl.className = "status expired";
      } else if (daysLeft < 30) {
        statusEl.textContent = "Expiring Soon";
        statusEl.className = "status warning";
      } else {
        statusEl.textContent = "Valid";
        statusEl.className = "status valid";
      }
    }
  });
}

document.addEventListener("DOMContentLoaded", updateInventory);
