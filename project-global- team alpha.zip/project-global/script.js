

// 🌐 Toggle hamburger menu
function toggleMenu() {
  document.getElementById("navLinks").classList.toggle("show");
}

// 📜 Smooth scroll for nav links
document.querySelectorAll('.nav a').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const target = document.querySelector(link.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.getElementById("navLinks").classList.remove("show");
    }
  });
});

// 🎬 Reveal sections on scroll
const sections = document.querySelectorAll('.section');
const revealOnScroll = () => {
  const triggerBottom = window.innerHeight * 0.8;
  sections.forEach(sec => {
    const boxTop = sec.getBoundingClientRect().top;
    if (boxTop < triggerBottom) {
      sec.classList.add('show');
    }
  });
};
window.addEventListener('scroll', revealOnScroll);
revealOnScroll();

// 📊 Charts (requires Chart.js from CDN in HTML)
document.addEventListener("DOMContentLoaded", () => {
  // Temperature Monitoring - Line Chart
  const tempCtx = document.getElementById("tempChart");
  if (tempCtx) {
    new Chart(tempCtx, {
      type: "line",
      data: {
        labels: ["8AM", "10AM", "12PM", "2PM", "4PM", "6PM"],
        datasets: [{
          label: "Temperature (°C)",
          data: [2, 3, 4, 5, 4, 3],
          borderColor: "#00a8e8",
          backgroundColor: "rgba(0,168,232,0.3)",
          fill: true,
          tension: 0.3
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { color: "#ffffff" } }
        },
        scales: {
          x: { ticks: { color: "#ffffff" } },
          y: { ticks: { color: "#ffffff" }, beginAtZero: true }
        }
      }
    });
  }

  // Inventory - Pie Chart
  const invCtx = document.getElementById("invChart");
  if (invCtx) {
    new Chart(invCtx, {
      type: "pie",
      data: {
        labels: ["Available", "Used", "Expired"],
        datasets: [{
          data: [70, 20, 10],
          backgroundColor: ["#00a8e8", "#007ea7", "#003459"]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { color: "#ffffff" } }
        }
      }
    });
  }

  // Logistics - Bar Chart
  const logCtx = document.getElementById("logChart");
  if (logCtx) {
    new Chart(logCtx, {
      type: "bar",
      data: {
        labels: ["Drone 1", "Drone 2", "Truck 1", "Truck 2"],
        datasets: [{
          label: "Deliveries Completed",
          data: [5, 8, 12, 7],
          backgroundColor: ["#007ea7", "#00a8e8", "#003459", "#00171f"]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { color: "#ffffff" } }
        },
        scales: {
          x: { ticks: { color: "#ffffff" } },
          y: { ticks: { color: "#ffffff" }, beginAtZero: true }
        }
      }
    });
  }
});
// 🔢 Counter Animation
function animateCounters() {
  const counters = document.querySelectorAll('.counter');
  counters.forEach(counter => {
    const updateCount = () => {
      const target = +counter.getAttribute('data-target');
      const current = +counter.innerText;
      const increment = target / 200; // smaller divisor = slower animation

      if (current < target) {
        counter.innerText = Math.ceil(current + increment);
        setTimeout(updateCount, 15);
      } else {
        counter.innerText = target;
      }
    };
    updateCount();
  });
}

// Trigger counters when Dashboard section is visible
const dashboard = document.getElementById("dashboard");
const observer = new IntersectionObserver(entries => {
  if (entries[0].isIntersecting) {
    animateCounters();
    observer.disconnect(); // run once
  }
}, { threshold: 0.5 });

observer.observe(dashboard);

// Sample dataset
const dataset = {
  temperatureData: [
    { location: "Vaccine Fridge 1", currentTemp: 4, minTemp: 2, maxTemp: 5 },
    { location: "Vaccine Fridge 2", currentTemp: 3.8, minTemp: 2, maxTemp: 5 },
    { location: "Supply Box 1", currentTemp: 5, minTemp: 2, maxTemp: 8 },
    { location: "Supply Box 2", currentTemp: 4.2, minTemp: 2, maxTemp: 8 }
  ],
  inventoryData: [
    { vaccineType: "Covaxin", dosesAvailable: 1200, expiry: "2025-12-01" },
    { vaccineType: "Covishield", dosesAvailable: 1500, expiry: "2025-11-15" },
    { vaccineType: "Sputnik V", dosesAvailable: 800, expiry: "2025-10-30" }
  ],
  logisticsData: [
    { vehicle: "Van 1", status: "In Transit", currentLocation: "Bangalore East", deliveriesToday: 12 },
    { vehicle: "Drone 1", status: "Delivered", currentLocation: "Bangalore West", deliveriesToday: 8 },
    { vehicle: "Van 2", status: "In Transit", currentLocation: "Whitefield", deliveriesToday: 10 },
    { vehicle: "Drone 2", status: "In Transit", currentLocation: "Electronic City", deliveriesToday: 5 }
  ],
  mapLocations: [
    { name: "Vaccine Fridge 1", lat: 12.9274338, lng: 77.5243329 },
    { name: "Vaccine Fridge 2", lat: 12.9278, lng: 77.525 },
    { name: "Supply Box 1", lat: 12.926, lng: 77.5235 },
    { name: "Supply Box 2", lat: 12.9285, lng: 77.526 },
    { name: "Van 1", lat: 12.935, lng: 77.53 },
    { name: "Drone 1", lat: 12.92, lng: 77.515 }
  ]
};

// Initialize Leaflet map (lightweight JS map library)
const map = L.map('mapContainer').setView([12.9274338, 77.5243329], 15);

// OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Add markers for mapLocations
dataset.mapLocations.forEach(loc => {
  loc.marker = L.marker([loc.lat, loc.lng]).addTo(map).bindPopup(loc.name);
});

// Simulate movement for logistics vehicles
function moveLogistics() {
  dataset.mapLocations.forEach(loc => {
    if(loc.name.startsWith("Van") || loc.name.startsWith("Drone")) {
      // Randomly move marker slightly
      const latOffset = (Math.random() - 0.5) * 0.001;
      const lngOffset = (Math.random() - 0.5) * 0.001;
      loc.lat += latOffset;
      loc.lng += lngOffset;
      loc.marker.setLatLng([loc.lat, loc.lng]);
    }
  });
}

// Update every 2 seconds
setInterval(moveLogistics, 2000);
